package by.bsu.algorithms.lab1;

import by.bsu.algorithms.lab1.exception.IncorrectNumberException;
import by.bsu.algorithms.lab1.service.Experiment;
import by.bsu.algorithms.lab1.service.SortingAlg;

import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String... args) throws IncorrectNumberException {

        System.out.println("Enter size of array:");

        Scanner in = new Scanner(System.in);
        //максимальный размер массива
        int N = in.nextInt();
        if(N <= 0)
            throw new IncorrectNumberException("Incorrect number");


        System.out.println("Enter max element:");

        //максимальный элемент
        int M= in.nextInt();
        if(M <= 0)
            throw new IncorrectNumberException("Incorrect number");

        int[] arr = fillArray(N,M);

        //оптимальные K
   //     int minKMerge = Experiment.mergeInsertExperiment(arr);
   //     int minKQuick = Experiment.quickInsertExperiment(arr);

        SortingAlg.mergeInsertSort(arr, 500);
    //    System.out.println(Arrays.toString(arr));
        System.out.println("Amount of elementary operations: " + SortingAlg.operations);

    //  System.out.println("K for merge sorting: " + minKMerge);
    //  System.out.println("K for quick sorting: " + minKQuick);


    }

    public static int[] fillArray(int N, int M){
        int[] array = new int[N];
        for(int i = 0; i < N;i++){
            array[i] = random(M);
        }
        return array;

    }

    public static int random(int M){
        return (int) (Math.random() * M);
    }
}
