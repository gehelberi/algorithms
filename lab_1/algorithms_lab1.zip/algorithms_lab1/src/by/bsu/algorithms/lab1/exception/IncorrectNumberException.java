package by.bsu.algorithms.lab1.exception;

public class IncorrectNumberException extends Exception{
    public IncorrectNumberException() {
    }

    public IncorrectNumberException(String message) {
        super(message);
    }

    public IncorrectNumberException(String message, Throwable cause) {
        super(message, cause);
    }

    public IncorrectNumberException(Throwable cause) {
        super(cause);
    }
}
